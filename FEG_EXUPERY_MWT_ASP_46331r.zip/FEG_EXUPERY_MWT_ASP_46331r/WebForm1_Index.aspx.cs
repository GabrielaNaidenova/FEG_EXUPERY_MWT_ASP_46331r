﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace FEG_EXUPERY_MWT_ASP_46331r
{
    public partial class WebForm1_Nachalo : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void TextBox_Second_News_TextChanged(object sender, EventArgs e)
        {

        }

        protected void Button2_Procheti_oshte_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/WebForm2_About.aspx");
        }

        protected void Menu_nachalo_procheti_oshte_MenuItemClick(object sender, MenuEventArgs e)
        {

        }
    }
}